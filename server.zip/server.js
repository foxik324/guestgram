const express = require("express");
const http = require("http");
const cors = require("cors");
const { Server } = require("socket.io");
const fs = require("fs");
const path = require("path");

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "../public")));

const PORT = process.env.PORT || 3000;

const DB_FILE = path.join(__dirname, "database.json");

let db = {
    users: {},
    messages: []
};

if (fs.existsSync(DB_FILE)) {
    try {
        db = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
    } catch {
        console.log("Не удалось прочитать database.json");
    }
}

function saveDB() {
    fs.writeFileSync(
        DB_FILE,
        JSON.stringify(db, null, 2),
        "utf8"
    );
}

function cleanUsername(username) {
    return String(username || "")
        .trim()
        .replace(/^@/, "")
        .toLowerCase();
}

function publicUser(user) {
    return {
        username: user.username,
        name: user.name,
        avatar: user.avatar,
        bio: user.bio,
        online: user.online || false
    };
}

/* =========================
   STATUS
========================= */

app.get("/", (req, res) => {
    res.json({
        name: "GuestGram Server",
        status: "online"
    });
});

/* =========================
   USERS
========================= */

app.get("/users", (req, res) => {
    const users = Object.values(db.users).map(publicUser);
    res.json(users);
});

app.get("/users/:username", (req, res) => {
    const username = cleanUsername(req.params.username);
    const user = db.users[username];

    if (!user) {
        return res.status(404).json({
            error: "Пользователь не найден"
        });
    }

    res.json(publicUser(user));
});

/* =========================
   SOCKET.IO
========================= */

io.on("connection", socket => {

    console.log("Новое подключение:", socket.id);

    /*
        Вход
    */

    socket.on("login", ({ username }, callback) => {

        username = cleanUsername(username);

        if (!username) {
            return callback({
                success: false,
                error: "Введите юзернейм"
            });
        }

        if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
            return callback({
                success: false,
                error: "Юзернейм: 3–20 символов, только буквы, цифры и _"
            });
        }

        if (db.users[username] && db.users[username].socketId) {
            return callback({
                success: false,
                error: "Этот юзернейм уже используется"
            });
        }

        if (!db.users[username]) {
            db.users[username] = {
                username,
                name: username,
                avatar: "",
                bio: "",
                socketId: socket.id,
                online: true,
                createdAt: Date.now()
            };
        } else {
            db.users[username].socketId = socket.id;
            db.users[username].online = true;
        }

        socket.username = username;

        saveDB();

        callback({
            success: true,
            user: publicUser(db.users[username])
        });

        io.emit(
            "users:update",
            Object.values(db.users).map(publicUser)
        );

        console.log("Вошёл:", username);
    });

    /*
        Изменение профиля
    */

    socket.on("profile:update", ({ name, avatar, bio }, callback) => {

        const username = socket.username;

        if (!username || !db.users[username]) {
            return callback({
                success: false,
                error: "Вы не авторизованы"
            });
        }

        const user = db.users[username];

        user.name = String(name || username)
            .trim()
            .slice(0, 40);

        user.avatar = String(avatar || "")
            .trim()
            .slice(0, 500);

        user.bio = String(bio || "")
            .trim()
            .slice(0, 150);

        saveDB();

        callback({
            success: true,
            user: publicUser(user)
        });

        io.emit(
            "users:update",
            Object.values(db.users).map(publicUser)
        );
    });

    /*
        Отправка сообщения
    */

    socket.on("message:send", ({ to, text }, callback) => {

        const from = socket.username;
        to = cleanUsername(to);

        text = String(text || "").trim();

        if (!from || !db.users[from]) {
            return callback({
                success: false,
                error: "Вы не авторизованы"
            });
        }

        if (!to || !db.users[to]) {
            return callback({
                success: false,
                error: "Пользователь не найден"
            });
        }

        if (!text) {
            return callback({
                success: false,
                error: "Сообщение пустое"
            });
        }

        if (text.length > 2000) {
            return callback({
                success: false,
                error: "Сообщение слишком длинное"
            });
        }

        const message = {
            id:
                Date.now().toString() +
                Math.random().toString(36).slice(2),

            from,
            to,
            text,
            time: Date.now()
        };

        db.messages.push(message);

        saveDB();

        callback({
            success: true,
            message
        });

        /*
            Получатель
        */

        const receiver = db.users[to];

        if (receiver && receiver.socketId) {
            io.to(receiver.socketId).emit(
                "message:new",
                message
            );
        }

        /*
            Отправитель
        */

        socket.emit(
            "message:new",
            message
        );
    });

    /*
        Получение истории чата
    */

    socket.on("messages:get", ({ withUser }, callback) => {

        const username = socket.username;
        const other = cleanUsername(withUser);

        if (!username) {
            return callback({
                success: false,
                error: "Вы не авторизованы"
            });
        }

        const messages = db.messages.filter(message => {

            return (
                (message.from === username &&
                    message.to === other) ||

                (message.from === other &&
                    message.to === username)
            );

        });

        callback({
            success: true,
            messages
        });
    });

    /*
        Выход / отключение
    */

    socket.on("disconnect", () => {

        const username = socket.username;

        if (!username || !db.users[username]) {
            return;
        }

        /*
            Если пользователь переподключился,
            не ставим его оффлайн ошибочно.
        */

        if (db.users[username].socketId === socket.id) {

            db.users[username].socketId = null;
            db.users[username].online = false;

            saveDB();

            io.emit(
                "users:update",
                Object.values(db.users).map(publicUser)
            );
        }

        console.log("Отключился:", username);
    });

});


server.listen(PORT, "0.0.0.0", () => {
    console.log(`GuestGram server запущен на порту ${PORT}`);
});